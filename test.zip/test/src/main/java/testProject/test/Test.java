package testProject.test;

public class Test{

	  
	   public static void main(String[]ar){


	   }

	   static{

	      System.out.println("Hello");
	   }
	}