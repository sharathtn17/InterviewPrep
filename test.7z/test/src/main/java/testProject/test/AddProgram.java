package testProject.test;

public class AddProgram {
	
	public static void main(String args[])
	{
		
		int n=6;
		int[] a = new int[30];
		int temp;
		
		for(int i=1;i<=n;i++)
		{
			
			for(int j=0;j<n;j++)
			{
				System.out.print(j+i);
				
			}
			
			
			System.out.println();
		}
		
		
		
		
		
	}

}
