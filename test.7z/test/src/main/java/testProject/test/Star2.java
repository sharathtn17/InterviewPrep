package testProject.test;

public class Star2 {

	
	public static void main(String[] args)
	
	{ int k=5;
		for(int i=0;i<5;i++)
			
			{for(int j=0;j<=i;j++)
			{
				System.out.print(" ");
			}
			
			for(int j=5;j>i;j--)
			{
				System.out.print("* ");
			}
			
			System.out.println();
		}
	}
}
