package testProject.test;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;

public class searchkey {
	public static void main(String[] args) {
		int i=07;
	//	int j=10;
		
		System.out.print(i);
	}
	
}
